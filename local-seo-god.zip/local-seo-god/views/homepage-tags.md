This is a list of tags specifically for homepage word replacement. any time the tag is visible in the page, including page title and meta data, the tag will be replaced.

{One-WordLiner}
{Main-Keyword}
{GMB-Service}
{Business-Name}
{Target-Location}
{Target-Keyword}

------------------------

Then, there are tag replacements that need to be replaced with html so that they link to an internal site link. these will be services of the business. so each tag will need to be replaced with a html structure that contains multiple other tags.

the tag will be {service-1}, {service-2}. basically {service-(prefix number of service.)}

the structure of each service title will be:
<a href="https://www.{Domain-Name}.com.au/{Service-1}-{Target-Location}">{service-1}</a>
depending on however many services the user lists in the business information section, it will add this many tags with this structure known. so the prefix of -1 like the example, would change to -2, -3, -4 etc. The same tag will already be updated on the existing wordpress page.