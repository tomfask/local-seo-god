This is all of the inputs that the user will need to fill out in the plugin settings under "business information"
this info will be stored and used for the tags as well as content generation.


Business Name: (Input: [Business Name]) {Business-Name}


GMB Service (Main Category): (Input: [Main Service, e.g., Concrete Contractor, Plumber, Electrician]) {GMB-Service}


Target Location (Main City for Service Page): (Input: [City or Area, e.g., Mornington Peninsula, Melbourne, Sydney]) {Target-Location}


Main Keyword: (Input: [Most Important Keyword, e.g., "Concreter Mornington Peninsula"]) {Main-Keyword}


Target Keywords: (Input: [List of additional keywords, e.g., "Best Concreter in Melbourne", "Exposed Aggregate Concrete Mornington"]) {Target-Keyword}


Services Provided: (Input: [List of services, e.g., Concrete Driveways, Plumbing Repairs]) {Service-1} {Service-2} {Service-3} {Service-4} (the tag is {Service-(prefix number)})


Service Areas: (Input: [List of locations, e.g., Mount Martha, Mornington, Safety Beach]) {area-1} {area-2} {area-3} {area-4} (the tag is {area-(prefix number)})


Website Domain Name: (Input: [Domain Name, e.g., examplebusiness.com.au]) {domain}


Business Description: (Textarea: [Detailed description of the business, e.g., "We are a family owned business with over 30+ years of experience in the concrete industry. Our team of experts specializes in creating beautiful, durable concrete surfaces for residential and commercial properties."]) {Business-Description}


Social Media Links:


Instagram: (Input: [Instagram Link])


Facebook: (Input: [Facebook Link])


GMB Profile Link: (Input: [GMB Profile URL])
